require 'pusher'
require 'sinatra'

get '/' do
  erb :index
end

post '/send' do
  pusher_client = Pusher::Client.new(
    app_id: '1993',
    key: 'f7500ad3992b6a9f7f62',
    secret: '2e2cf2e40bf99e0d61b8',
    host: 'api.staging.pusher.com',
    encrypted: true,
    notification_host: 'hedwig-staging.herokuapp.com'
  )

  pusher_client.notify(["donuts"], {
    apns: {
      aps: {
        alert: {
          body: params["message"]
        }
      }
    }
  })

  erb :index
end